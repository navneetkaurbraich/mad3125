package com.example.macstudent.kns_goparking;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class ReportActivity extends AppCompatActivity {

    ListView receiptList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        receiptList = (ListView) findViewById(R.id.list_receipt);
        receiptList.setAdapter(new ReportAdapter(getApplicationContext()));
    }
}
