package com.example.macstudent.kns_goparking;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class UserProfileActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnUpdate;
    TextView txtname, txtphone, txtemail, txtdob;
    DBHelper dbHelper;
    SQLiteDatabase parkingDB;

    @Override
    public void onBackPressed() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        startActivity(mainIntent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        SharedPreferences sp = getSharedPreferences("com.example.student.macstudent.kns_goparking.shared", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();









    }

    @Override
    public void onClick(View view) {

    }
}
