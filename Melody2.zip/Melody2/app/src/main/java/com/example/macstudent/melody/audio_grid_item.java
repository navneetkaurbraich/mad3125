package com.example.macstudent.melody;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class audio_grid_item extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_grid_item);
    }
}
