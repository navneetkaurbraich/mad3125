package com.example.macstudent.melody;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by macstudent on 2018-04-23.
 */

public class AudioAdapter extends BaseAdapter {

    String names[] = {"Song1","Song2","Song3","Song4"};
    String images[] = {"image.png","img.png","mus.jpg","music.jpg"};
    LayoutInflater layoutInflater;
    Context context;
    TextView txtInitial;
    TextView txtPhone;
    View convertView;
    int totalContacts = 0;
    ArrayList<String> arName;
    ArrayList<String> arImages;

    AudioAdapter(Context context) {
        this.context = context;
        arName = new ArrayList<String>();
        arImages = new ArrayList<String>();
        getAudioList();
        layoutInflater = (LayoutInflater.from(context));
    }

        @Override
        public int getCount() {
            return totalContacts;
        }

        @Override
        public Object getItem ( int i){
            return i;
        }

        @Override
        public long getItemId ( int i){
            return i;
        }

        @Override
        public View getView ( int i, View view, ViewGroup viewGroup){
            convertView = layoutInflater.inflate(R.layout.activity_audio_grid_item, null);

            txtInitial = convertView.findViewById(R.id.audioTitle);
            txtInitial.setText(String.valueOf(arName.get(i).charAt(0)));

            txtPhone = convertView.findViewById(R.id.);
            txtPhone.setText(arImages.get(i));

            return convertView;
        }

    private void getAudioList() {
        ContentResolver cr = context.getContentResolver();
        Cursor cursor = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);

        if ((cursor != null ? cursor.getCount() : 0) > 0) {
            totalContacts = cursor.getCount();

            while (cursor != null && cursor.moveToNext()) {
                String id = cursor.getString(
                        cursor.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cursor.getString(cursor.getColumnIndex(
                        ContactsContract.Contacts.DISPLAY_NAME));

                if (cursor.getInt(cursor.getColumnIndex(
                        ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCur = cr.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);

                    while (pCur.moveToNext()) {
                        String phoneNo = pCur.getString(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NUMBER));

                        arName.add(name);
                        arImages.add(phoneNo);
                        Log.i("contactList", " Song Name: " + name);
                        Log.i("contactList", "Images : " + phoneNo);
                    }
                    pCur.close();
                }
            }
        }
        if (cursor != null) {
            cursor.close();
        }

    }

}


